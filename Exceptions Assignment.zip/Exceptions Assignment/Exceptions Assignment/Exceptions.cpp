// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

bool do_even_more_custom_application_logic()
{
    // Throw any standard exception
    try {

        std::cout << "Running Even More Custom Application Logic." << std::endl;
        return true;
    }
    catch (...) {
        std::cout << "Default exception thrown, in do_even_more_custom.\n";

    }
}
void do_custom_application_logic()
{
    //  Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    /*
    * Try/catch exception e to be caught in main 
    */
    std::cout << "Running Custom Application Logic." << std::endl;
    try {


        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }

        std::cout << "Leaving Custom Application Logic." << std::endl;

        //  Throw a custom exception derived from std::exception
        //  and catch it explictly in main
    }
    catch (std::exception& e) { 

        std::cerr << "exception caught: " << e.what() << '\n'; // outputs exception caught and .what() lists it.
    }

}

float divide(float num, float den)
{
    //  Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    // if denominator is 0, throw error.
    if (den == 0) {
        throw std::invalid_argument("Invalid argument, denominator cannot be 0.\n");
    }
    return (num / den);
}   

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.
     
    float numerator = 10.0f;
    float denominator = 0;

    try {

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (std::invalid_argument& e) {
        std::cerr << "do_division error thrown: " << e.what() << std::endl; // lists error caught from divide.

    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;
    try {
        do_division();
    }
    catch (std::invalid_argument& e) { // custom exception

        std::cerr << "Main error, do_division thrown: " << e.what() << std::endl;

    }

    try {
        do_custom_application_logic();
    }
    catch (std::runtime_error& e) { // standard std::exception

        std::cerr << "Main error, do_Custom_application thrown: " << e.what() << std::endl;
    }
    catch (...) { // any uncaught exception will be caught by default.
        std::cout << "Default exception caught." << std::endl;
    }

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.
    // removed this to add to try catch do_division();
    //do_custom_application_logic();
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu    